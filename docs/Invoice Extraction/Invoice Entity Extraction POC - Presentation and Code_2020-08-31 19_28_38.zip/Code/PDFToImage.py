# -*- coding: utf-8 -*-
"""
Created on Sun Jul 26 16:21:36 2020

@author: 703069554
"""

import time
import pyautogui
import cv2
import numpy as np
import win32api
#strOutFL = "./Process/PDFToImage"
def PDFToImageFN(strOutFL):
    def stitchImage(img1, img2):
        hLine1 = []
        hLine2 = []   
        
        for i in range(img1.shape[0]):
            hLine1.append(np.mean(img1[i,:]))
        
        for i in range(img2.shape[0]):
            hLine2.append(np.mean(img2[i,:]))
    
        matchLine = 0
        for i in range(img1.shape[0]):
            if np.sum(np.array(hLine1[-i:]) == np.array(hLine2[0:i])) == i :
                if int(i) > int(matchLine) :
                    matchLine = i
        img1 = img1[0: img1.shape[0]-matchLine,:]
        #print(img1.shape)
        #print(img2.shape)
        if matchLine == img1.shape[0] or matchLine == img1.shape[1] or np.array_equal(img1,img2):
            return img1,0
        else :
            imgCombine = np.concatenate((img1,img2),axis = 0)  
            return imgCombine,1
     #region = (300,130,800,580)
    
    #time.sleep(2)
    #pyautogui.screenshot().save("./Process/SC1.png")  
    #img1 = cv2.imread("./Process/SC1.png",0)
    time.sleep(2)
    reg = (130,130,880,590)
    #print(win32api.GetCursorPos())
    img1 = cv2.cvtColor(np.array(pyautogui.screenshot(region = reg )), cv2.COLOR_BGR2GRAY)
    #cv2.imwrite('./Process/Test.png',img1)
    pyautogui.keyDown('pagedown')
    time.sleep(1)    
    img2 = cv2.cvtColor(np.array(pyautogui.screenshot(region = reg)), cv2.COLOR_BGR2GRAY)
    imgCombine,stopFlag = stitchImage(img1,img2)

    pyautogui.keyDown('pagedown')
    time.sleep(1)    
    img3 = cv2.cvtColor(np.array(pyautogui.screenshot(region = reg)), cv2.COLOR_BGR2GRAY)
    if not np.array_equal(img2,img3) :
        imgCombine,stopFlag = stitchImage(imgCombine,img3)

    pyautogui.keyDown('pagedown')
    time.sleep(1)    
    img4 = cv2.cvtColor(np.array(pyautogui.screenshot(region = reg)), cv2.COLOR_BGR2GRAY)
    if not np.array_equal(img3,img4) :
        imgCombine,stopFlag = stitchImage(imgCombine,img4)
    
    pyautogui.keyDown('pagedown')
    time.sleep(1)    
    img5 = cv2.cvtColor(np.array(pyautogui.screenshot(region = reg)), cv2.COLOR_BGR2GRAY)
    if not np.array_equal(img4,img5) :
        imgCombine,stopFlag = stitchImage(imgCombine,img5)
    
    print(strOutFL)
    #print (stopFlag)
    cv2.imwrite(strOutFL + '.png',imgCombine)        
    #imgCombine.shape