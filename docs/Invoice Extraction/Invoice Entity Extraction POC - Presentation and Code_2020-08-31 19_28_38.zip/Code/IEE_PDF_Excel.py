# -*- coding: utf-8 -*-
"""
Created on Thu Jul 23 16:53:08 2020

@author: 703069554
"""
#https://pyautogui.readthedocs.io/en/latest/mouse.html
#https://www.pyimagesearch.com/2018/01/01/taking-screenshots-with-opencv-and-python/
#https://opencv-python-tutroals.readthedocs.io/en/latest/py_tutorials/py_imgproc/py_template_matching/py_template_matching.html

import time
import pyautogui
import cv2
import numpy as np
import win32api
import os
import random
#from tkinter import messagebox

#from subprocess import call
strPath = "D:\\Users\\703069554\\OneDrive - Genpact\\Python Projects\\Invoice Entity Extraction"
os.chdir(strPath)
import sys

sys.path.insert(0, './Code')

from os import listdir
#from os.path import isfile, join

from TMUD_ImageToExcel import ImageToExcel
from PDFToImage import PDFToImageFN
from GetTableFromImage import GetTableFromImage
from IEE_MarkTable import MarkTable


onlyfiles = [f for f in listdir(strPath+"./Input") ]

def Compare(image,strTemplate) :
    #image = cv2.imread('./Input/in_memory_to_disk.png',0)
    #image = np.array(pyautogui.screenshot())
    #strTemplate = 'AdobeOpen'
    image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
    img_rgb = image
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    template = cv2.imread('./Templates/'+strTemplate+'.png',0) 
    w, h = template.shape[::-1]
    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    threshold = 0.9
    loc = np.where( res >= threshold)
    if (loc[0][0] >0 or loc[1][0] > 0) :
        return loc[1][0]+w/2, loc[0][0]+h/2
    else :
        return 0,0

def ClickTemplate(sb,template,MPH,MPV,scrlUD,SHH,SHV,t,l,w,h,CF,sa) :
    time.sleep(sb)
    RetFlag = 1
    if MPH > 0 or MPV > 0 :
        pyautogui.moveTo(MPH,MPV)
    
    if t > 0 or l> 0 or w>0 or h>0:
        Cx, Cy = win32api.GetCursorPos()
        image = pyautogui.screenshot(region=(Cx+t,Cy + l,w,h))
        image = cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)
        #cv2.imwrite("./Input/in_memory_to_disk.png", image)
        x,y = Compare(image,template)
    else :
        Cx,Cy = 0,0
        x,y = Compare(np.array(pyautogui.screenshot()),template)
    i = 0
    if x > 0 or y> 0:
        #print(x + SHH + Cx,y + SHV + Cy)
        if CF>0:
            pyautogui.click(x + SHH + Cx + t,y + SHV + Cy + l)
            RetFlag = 0
        else:
            pyautogui.moveTo(x + SHH + Cx +t,y + SHV + Cy + l)
            RetFlag = 0
    else :
        while i < 10:
            if scrlUD < 0 :
                pyautogui.scroll(-400) 
            elif scrlUD > 0 :
                pyautogui.scroll(400)
            time.sleep(0.1)
            if t > 0 or l> 0 or w>0 or h>0:
                Cx, Cy = win32api.GetCursorPos()
                x,y = Compare(np.array(pyautogui.screenshot((Cx+t,Cy + l,w,h))),template)
            else :
                Cx, Cy = 0,0
                x,y = Compare(np.array(pyautogui.screenshot()),template)
            if x > 0 or y> 0:
                #print(x + SHH + Cx,y + SHV + Cy)
                if CF>0:
                    pyautogui.click(x + SHH + Cx + t,y + SHV + Cy + l)
                    RetFlag = 0
                else:
                    pyautogui.moveTo(x + SHH + Cx + t,y + SHV + Cy + l)
                    RetFlag = 0
                i = 11
            i = i + 1
    time.sleep(sa)
    return RetFlag

#sb,template,MPH,MPV,scrlUD,SHH,SHV,t,l,w,h,CF,sa
    
print(ClickTemplate(1,'Windows',0,0,0,0,0,0,0,0,0,1,1))
print(ClickTemplate(1,'AdobeAcrobat',200,500,1,0,0,0,0,0,0,1,3))

#onlyfiles = ['template1_2537_59385.pdf','template2_2039_65445.pdf'
#                    ,'template2_1123_89959.pdf','template3_1494_31608.pdf']

random.seed(10)
#onlyfilesRandom = random.sample(onlyfiles , k = 780)
#Error:'template2_16_60.pdf'
#onlyfilesRandomSub = onlyfilesRandom[50:600]
#onlyfilesRandom = ['template2_16_60.pdf']
for fl in onlyfiles:
#   fl = 'template1_2506_54229.pdf'
    print("Processing : " + fl)
    print(ClickTemplate(3,'AdobeFile',0,0,0,0,0,0,0,0,0,1,1))
                        
    print(ClickTemplate(1,'AdobeCTRLO',0,0,0,0,0,0,0,0,0,1,1))
    
    pyautogui.typewrite(str(len([f for f in listdir(strPath+"/Images")])))
    time.sleep(1)
    pyautogui.press('backspace',10)
    pyautogui.typewrite(strPath+"\\Input\\" + fl)
    print(ClickTemplate(1,'Adobe_FileOpen',0,0,0,0,0,0,0,0,0,1,3))
    
    try:
        print(ClickTemplate(2,'AdobeCollapse',0,0,0,0,0,0,0,0,0,1,3))
    except:
        print("An exception occurred")
        
    print(ClickTemplate(3,'AdobeZoom',0,0,0,80,0,0,0,0,0,1,2))
    pyautogui.typewrite('100',0.01)
    pyautogui.press('return')
    
    #call(["python", "./Code/PDFToImage.py"])
    PDFToImageFN('./Images/'+ fl)
    GetTableFromImage('./Images/' + fl + '.png')
    MarkTable()
    ImageToExcel(fl)
    print(ClickTemplate(1,'AdobeCloseFile2',0,0,0,0,0,0,0,0,0,1,1))
    
print(ClickTemplate(1,'AdobeClose',0,0,0,40,0,0,0,0,0,1,1))


"""
ImgFiles = [f for f in listdir(strPath+"./Images")] 

for fl in ImgFiles :
    fl = 'template3_990_22422.pdf.png'
    GetTableFromImage('./Images/' + fl)

"""


"""
# uncomment for full run
for fl in onlyfiles[0:2] :

    print(ClickTemplate(3,'AdobeFile',0,0,0,0,0,0,0,0,0,1,1))
    print(ClickTemplate(1,'AdobeOpen',0,0,0,0,0,0,0,0,0,1,1))

    print("Processing : " + fl)
    pyautogui.typewrite(strPath+"\\Gslove_1.5K_data\\" + fl)
    print(ClickTemplate(1,'Adobe_FileOpen',0,0,0,0,0,0,0,0,0,1,1))
    print(ClickTemplate(5,'AdobeZoom',0,0,0,80,0,0,0,0,0,1,1))
    pyautogui.typewrite('100')
    pyautogui.press('return')
    
    call(["python", "./Code/PDFToImage.py"])
    print(ClickTemplate(1,'AdobeCloseFile',0,0,0,0,0,0,0,0,0,1,1))

    call(["python", "./Code/GetTableFromImage.py"])
    call(["python", "./Code/IEE_MarkTable.py"])
    ImageToExcel(fl)
    
print(ClickTemplate(1,'AdobeClose',0,0,0,40,0,0,0,0,0,1,1))
"""

"""
ImageFiles = [f for f in listdir(strPath+"./Images")] 

for FLI in ImageFiles :
    FLIimg = cv2.imread(strPath+"./Images/" + FLI,0)
    cv2.imwrite('./Images_Resize/R_' + FLI,cv2.resize(FLIimg,(100,100)))

"""
