# -*- coding: utf-8 -*-
"""
Created on Sat Jul 25 23:41:53 2020

@author: 703069554
"""

import cv2
import numpy as np
import os

#os.chdir("D:/Users/703069554/OneDrive - Genpact/Python Projects/Invoice Entity Extraction")
#os.getcwd()

def GetTableFromImage(fl) :  
    #img_rgb = cv2.imread('./Input/Template_Table_Extract.PNG')
    img_rgb = cv2.imread(fl)
    cv2.imwrite('./Process/PDFToImage.png',img_rgb)
    img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    template = cv2.imread('./Templates/TableHeader.PNG',0)
    w1, h1 = template.shape[::-1]
    
    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    threshold = 0.99
    loc = np.where( res >= threshold)
    for pt in zip(*loc[::-1]):
        #cv2.rectangle(img_rgb, pt, (pt[0] + w1, pt[1] + h1), (0,0,255), 2)
        pt10,pt11 = pt[0],pt[1]
        
    img_rgb[loc[0],loc[1]] = 0
    
    template = cv2.imread('./Templates/FooterLine.PNG',0)
    w2, h2 = template.shape[::-1]
    
    res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED)
    threshold = 0.99
    loc = np.where( res >= threshold)
    for pt in zip(*loc[::-1]):
        #cv2.rectangle(img_rgb, pt, (pt[0] + w2, pt[1] + h2), (0,0,255), 2)
        pt20,pt21 = pt[0],pt[1]
        
    img_rgb1 = img_rgb[pt11+h1 :pt21,np.min((pt10,pt20)):pt10+w1]  #top:last,left:right
    
    cv2.imwrite('./Process/TableCaptureTemplate.png',img_rgb1)