# -*- coding: utf-8 -*-
"""
Created on Sun Dec  1 21:39:23 2019

@author: 703069554
"""

import cv2
import numpy as np
import os
import pytesseract
import pandas as pd

def ImageToExcel(strOutFL):
    pytesseract.pytesseract.tesseract_cmd = r'D:\Users\703069554\AppData\Local\Continuum\anaconda3\Library\bin\tesseract.exe'
    #os.chdir("D:/Users/703069554/OneDrive - Genpact/Python Projects/Invoice Entity Extraction")
    # Read the image
    img = cv2.imread("./Process/MarkedTable.png", 0)
     
    # Thresholding the image
    (thresh, img_bin) = cv2.threshold(img, 128, 255,cv2.THRESH_BINARY|     cv2.THRESH_OTSU)
    # Invert the image
    img_bin = 255-img_bin 
    cv2.imwrite("Image_bin.jpg",img_bin)
    
    
    # Defining a kernel length
    kernel_length = np.array(img).shape[1]//80
     
    # A verticle kernel of (1 X kernel_length), which will detect all the verticle lines from the image.
    verticle_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (1, kernel_length))
    # A horizontal kernel of (kernel_length X 1), which will help to detect all the horizontal line from the image.
    hori_kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (kernel_length, 1))
    # A kernel of (3 X 3) ones.
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    
    
    # Morphological operation to detect vertical lines from an image
    img_temp1 = cv2.erode(img_bin, verticle_kernel, iterations=3)
    verticle_lines_img = cv2.dilate(img_temp1, verticle_kernel, iterations=3)
    cv2.imwrite("verticle_lines.jpg",verticle_lines_img)
    # Morphological operation to detect horizontal lines from an image
    img_temp2 = cv2.erode(img_bin, hori_kernel, iterations=3)
    horizontal_lines_img = cv2.dilate(img_temp2, hori_kernel, iterations=3)
    cv2.imwrite("horizontal_lines.jpg",horizontal_lines_img)
    
    # Weighting parameters, this will decide the quantity of an image to be added to make a new image.
    alpha = 0.5
    beta = 1.0 - alpha
    # This function helps to add two image with specific weight parameter to get a third image as summation of two image.
    img_final_bin = cv2.addWeighted(verticle_lines_img, alpha, horizontal_lines_img, beta, 0.0)
    img_final_bin = cv2.erode(~img_final_bin, kernel, iterations=2)
    (thresh, img_final_bin) = cv2.threshold(img_final_bin, 128,255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)
    cv2.imwrite("img_final_bin.jpg",img_final_bin)
    
    image = cv2.imread('img_final_bin.jpg')
    
    #morph_size=(8, 8)
    pre = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        # Otsu threshold
    pre = cv2.threshold(pre, 250, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    # dilate the text to make it solid spot
    cpy = pre.copy()
    #struct = cv2.getStructuringElement(cv2.MORPH_RECT, morph_size)
    #cpy = cv2.dilate(~cpy, struct, anchor=(-1, -1), iterations=1)
    
    cv2.imwrite('./cpy.png',cpy)
    
    image = cv2.imread('img_final_bin.jpg')
    pre = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    pre = 255-pre
    ret, thresh = cv2.threshold(pre, 127, 255, 0)
    contours, hierarchy = cv2.findContours(thresh, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    #cnt = contours[4]
    frame = np.zeros((img.shape[0],img.shape[1]))
    frame.fill(255)
    #cv2.drawContours(frame, contours,-1, (0,0,125), 1)
    
    
    boundingBoxes = [cv2.boundingRect(c) for c in contours]
    cv2.groupRectangles(boundingBoxes,1,0.5)
    hierarchy[0][0][3]
    
    p = []
    for i in range(len(contours)):
        p.append(hierarchy[0][i][3])
    p
    
    #frame = img
    cv2.imwrite('./Process/img_before.png',img)
    j = 0
    cells = []
    tables = set()
    #miny = frame.shape[0]
    #maxy = 0
    #minx = frame.shape[1]
    #maxx = 0
    text = []
    
    def GetValue(imgtest,numFlag):
        #imgtest = cv2.imread("./Output/5.png", 0)
        #imgtest = cv2.blur(imgtest,(2,2),0)
        kernel = np.array([[0, -1, 0], 
                           [-1, 5,-1], 
                           [0, -1, 0]])
        # Sharpen image
        imgtest = cv2.filter2D(imgtest, -1, kernel)
        
        h,w=imgtest.shape[0:2]
        base_size=h+40,w+40
        # make a 3 channel image for base which is slightly larger than target img
        base=np.zeros(base_size,dtype=np.uint8)
        cv2.rectangle(base,(0,0),(w+40,h+40),(255,255,255),60) # really thick white rectangle
        base[20:h+20,20:w+20]=imgtest # this works
        base = cv2.resize(base,(base.shape[1]*1,base.shape[0]*1))
        cv2.imwrite("./Process/imgtest.png",base)
        if numFlag == 1 and np.sum(base<220) >0 :
            return pytesseract.image_to_string(base,config='--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789')
        else:
            return pytesseract.image_to_string(base)
            #pytesseract.image_to_string(imgtest)
    
    for i in range(len(contours)-1, -1, -1):
        color= (128,128,128)
        
        #cv2.putText(frame,i ,(boundingBoxes[i][0],boundingBoxes[i][1]),cv2.FONT_HERSHEY_SIMPLEX,0.5,(0,255,0))
        if hierarchy[0][i][0] * hierarchy[0][i][1] == 1 or hierarchy[0][i][2] * hierarchy[0][i][3] ==1 :
            print("none")
        else:
            #if boundingBoxes[i][2] / frame.shape[0] < .5: 
            print("contour" + str(i))
            tables.add(hierarchy[0][i][3])
            cv2.rectangle(frame, (int(boundingBoxes[i][0]), int(boundingBoxes[i][1])), (int(boundingBoxes[i][0]+boundingBoxes[i][2]), int(boundingBoxes[i][1]+boundingBoxes[i][3])), color, 1)
            #print(contours[i])
            #cv2.putText(frame,str(i)+"+" + ("".join(str(hierarchy[0][i]))) ,(boundingBoxes[i][0],boundingBoxes[i][1]),cv2.FONT_HERSHEY_SIMPLEX,0.25,(0,128,0))
            print("C" + str(j))
            print(boundingBoxes[i][0])
            cells.append(boundingBoxes[i][0])
            y,x,h,w = boundingBoxes[i][0],boundingBoxes[i][1],boundingBoxes[i][2],boundingBoxes[i][3]
            cv2.putText(frame,str(j) ,( y, x),cv2.FONT_HERSHEY_SIMPLEX,0.25,(0,128,0))
            
            #cv2.imwrite("./Output/" + str(j)+".png",img[x:x+w,y:y+h] )
            
            #text.append(pytesseract.image_to_string(img[x:x+w,y:y+h]))
            if i%3 ==0:
                text.append(GetValue(img[x:x+w,y:y+h],0))
            else :
                text.append(GetValue(img[x:x+w,y:y+h],1))
                
            img[x:x+w,y:y+h] = 255
            
    #            minx = min(minx,x)
    #            maxx = max(maxx,x)
    #            miny = min(miny+y,y)
    #            maxy = max(maxy+x,y)
    #            img[minx:maxx,miny:maxy] = 255
            
            j = j+1
    #print(hierarchy[0][i])
    cells_rc = np.unique(cells,return_counts = True)
    cells_rc = [np.count_nonzero(cells_rc[0]),np.max(cells_rc[1])]
    cells_rc
    
    for i in tables:
        y,x,h,w = boundingBoxes[i][0],boundingBoxes[i][1],boundingBoxes[i][2],boundingBoxes[i][3]
        #img[x+2:x+w,y+2:y+h] = 255
    #frame = cv2.merge([frame,img,frame])
    
    cv2.imwrite('./Process/frame.png',frame )
    cv2.imwrite('./Process/img.png',img)
        
    text = np.reshape(text,(cells_rc[1],cells_rc[0]))
    text = pd.DataFrame(text)
    
    for i in range(text.shape[0]):
        if text[1][i] == "" and text[2][i] == "":
            text[0][i-1] = text[0][i-1]+" "+(text[0][i])
            
    text.drop(text[(text[1]=="") & (text[2]=="" )].index,inplace = True)
        
    text.to_excel('./Output/'+ strOutFL +'.xlsx',index = False,header = False)
    
    #text.append(pytesseract.image_to_string
    
    
