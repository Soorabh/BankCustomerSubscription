# -*- coding: utf-8 -*-
"""
Created on Sun Dec  1 21:39:23 2019

@author: 703069554
"""
#https://stackoverflow.com/questions/50829874/how-to-find-table-like-structure-in-image
import cv2
import numpy as np
import os
import pytesseract
import pandas as pd
#import matplotlib.pyplot as plt

#pytesseract.pytesseract.tesseract_cmd = r'D:\Users\703069554\AppData\Local\Continuum\anaconda3\Library\bin\tesseract.exe'


#os.chdir("D:/Users/703069554/OneDrive - Genpact/Python Projects/Invoice Entity Extraction")
# Read the image
def MarkTable() :
    img = cv2.imread("./Process/TableCaptureTemplate.png", 0)
     
    # Thresholding the image
    (thresh, img_bin_1) = cv2.threshold(img, 128, 255,cv2.THRESH_BINARY|cv2.THRESH_OTSU)
    # Invert the image
    g= img_bin_1
    img_bin = 255-img_bin_1
    cv2.imwrite("./Process/Image_bin.jpg",img_bin)
    
    
    blur = cv2.GaussianBlur(g, (1, 1), 0)
    cv2.imwrite("./Process/blur.jpg",blur)
    
    ret, thresh1 = cv2.threshold(blur, 150, 255, cv2.THRESH_BINARY)
    bitwise = cv2.bitwise_not(thresh1)
    erosion = cv2.erode(bitwise, np.ones((1, 1) ,np.uint8), iterations=2)
    dilation = cv2.dilate(erosion, np.ones((2, 2) ,np.uint8), iterations=2)
    
    cv2.imwrite("./Process/dilation.jpg",dilation)
    
    imgmean = dilation
    dilation1 = dilation.copy()
    
    #dfmean = pd.DataFrame({'meanx':[],'meany':[]})
    imgmeanavg = imgmean  
    hLines=[]
    for i in range(imgmean.shape[0]) :
        hLines.append( np.sum(imgmean[i,:]>0))
        for j in range(imgmean.shape[1]):
             imgmeanavg[i,j] = np.mean(imgmean[i,:])
             
    cv2.imwrite("./Process/imgmeanavgH.jpg",imgmeanavg)
    
    imgCopy = img.copy()
    hLinesD = hLines
    hLinesD = [1 if x >0  else 0 for x in hLines  ]
    hLinesD = [np.abs(y-x) for x, y in zip(hLinesD[:-1], hLinesD[1:])] 
    hLinesD.append(0)
    color = (0, 255, 0) 
    hLinesD = pd.Series(hLinesD).cumsum()
    lineno = []
    tot = []
    cnt = 0
    for i in range(imgmean.shape[0]) :
        if hLinesD[i] % 2 == 0 :
            #imgHL = cv2.line(img, (0,i), (10,i), color, 1) 
            tot.append(i)
            cnt = 1
        else :
            if cnt ==1 :
                lineno.append(np.median(tot))
                tot = []
            cnt = 0
    for i in range(imgmean.shape[0]) :
        if i in set(np.round(lineno,0)) :
            imgHL = cv2.line(img, (0,i), (imgmean.shape[1],i), color, 1) 
    cv2.imwrite("./Process/imgHL.jpg",imgHL)
    
    cv2.imwrite("./Process/dilation1.jpg",dilation1)
    
    imgmeanV = dilation1
    #dfmean = pd.DataFrame({'meanx':[],'meany':[]})
    imgmeanavgV = imgmeanV  
    vLines=[]
    for j in range(imgmeanV.shape[1]) :
        vLines.append( np.sum(imgmeanV[:,j]>0))
        for i in range(imgmeanV.shape[0]):
             imgmeanavgV[i,j] = np.mean(imgmeanV[:,j])
             
    cv2.imwrite("./Process/imgmeanavgV.jpg",imgmeanavgV)
    
    vLinesD = vLines
    vLinesD = [1 if x >0  else 0 for x in vLines  ]
    vLinesD = [np.abs(y-x) for x, y in zip(vLinesD[:-1], vLinesD[1:])] 
    vLinesD.append(0)
    color = (0, 255, 0) 
    vLinesD = pd.Series(vLinesD).cumsum()
    lineno = []
    tot = []
    cnt = 0
    cv2.imwrite("./Process/imgCopy .jpg",imgCopy )
    
    for j in range(imgmean.shape[1]) :
        if vLinesD[j] % 2 == 0 :
            imgVL = cv2.line(imgCopy , (j,0), (j,10), color, 1) 
            tot.append(j)
            cnt = 1
        else :
            if cnt ==1 :
                lineno.append(np.median(tot))
                tot = []
            cnt = 0
            
    for j in range(imgCopy.shape[1]) :
        if j in set(np.round(lineno,0)) :
            imgVL = cv2.line(imgHL , (j,0), (j,imgHL.shape[0]), color, 1) 
            
    imgVL = cv2.line(imgVL, (imgVL.shape[1]-1 ,0), (imgVL.shape[1]-1,imgVL.shape[0]), (0,0,0), 1) 
    imgVL = cv2.line(imgVL, ( 0,imgVL.shape[0]-1), (imgVL.shape[1],imgVL.shape[0]-1), (0,0,0), 1) 
    imgVL = cv2.line(imgVL, ( 0,0), (0,imgVL.shape[0]), (0,0,0), 1) 
    
    cv2.imwrite("./Process/imgVL.jpg",imgVL)
    
    h,w=imgVL.shape[0:2]
    base_size=h+40,w+40
    # make a 3 channel image for base which is slightly larger than target img
    base=np.zeros(base_size,dtype=np.uint8)
    cv2.rectangle(base,(0,0),(w+40,h+40),(255,255,255),60) # really thick white rectangle
    base[20:h+20,20:w+20]=imgVL # this works
    cv2.imwrite("./Process/MarkedTable.png",base)
        
    
    def GetValue(imgtest,numFlag):
        #imgtest = cv2.imread("./Output/5.png", 0)
        #imgtest = cv2.blur(imgtest,(2,2),0)
        kernel = np.array([[0, -1, 0], 
                           [-1, 5,-1], 
                           [0, -1, 0]])
        # Sharpen image
        imgtest = cv2.filter2D(imgtest, -1, kernel)
        
        h,w=imgtest.shape[0:2]
        base_size=h+40,w+40
        # make a 3 channel image for base which is slightly larger than target img
        base=np.zeros(base_size,dtype=np.uint8)
        cv2.rectangle(base,(0,0),(w+40,h+40),(255,255,255),60) # really thick white rectangle
        base[20:h+20,20:w+20]=imgtest # this works
        base = cv2.resize(base,(base.shape[1]*1,base.shape[0]*1))
        cv2.imwrite("./Process/imgtest.png",base)
        if numFlag == 1 and np.sum(base<220) >0 :
            return pytesseract.image_to_string(base,config='--psm 10 --oem 3 -c tessedit_char_whitelist=0123456789')
        else:
            return pytesseract.image_to_string(base)
            #pytesseract.image_to_string(imgtest)
    
    #GetValue(cv2.imread("./Output/14.png", 0),1)
